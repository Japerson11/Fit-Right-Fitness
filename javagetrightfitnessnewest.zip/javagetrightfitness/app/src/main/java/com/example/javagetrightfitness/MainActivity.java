package com.example.javagetrightfitness;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // buttons and other controls
    Button btn_signin;
    EditText txtinput_password, txtinput_username;

    private static final String TAG = "MainActivity";
    private FitnessClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.i(TAG, "beginning of on create");
        btn_signin = findViewById(R.id.btn_signin);
        txtinput_password = findViewById(R.id.txtinput_password);
        txtinput_username = findViewById(R.id.txtinput_username);


        // sign in button listener
        btn_signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try
                {
                    client = new FitnessClient(-1, txtinput_username.getText().toString(), txtinput_password.getText().toString(), "null", 0, 0, 0.1, 1, "Male", "S", 0, 0, 0, 0);
                    Toast.makeText(MainActivity.this, "Welcome", Toast.LENGTH_SHORT).show();
                    setClient(client);


                }
                catch (Exception e)
                {
                    Toast.makeText(MainActivity.this, "Error occurred while logging in.", Toast.LENGTH_SHORT).show();
                    client = new FitnessClient(-1, "error", "error", "error", 0, 0, 0.1, 1, "Male", "S", 0 ,0, 0, 0);
                }

                DataBaseHelper dataBaseHelper = new DataBaseHelper(MainActivity.this);

                //boolean added = dataBaseHelper.addClient(client);

                //Toast.makeText(MainActivity.this, "added " + added, Toast.LENGTH_SHORT).show();
                //Log.i(TAG, "Added value for Database = " + added);

                Intent intent = new Intent(MainActivity.this, ClientInfo.class);
                intent.putExtra("ourClient", client.toString());
                startActivity(intent);


            }
        });



        }
        public void setClient(FitnessClient client){
            this.client = client;
        }
        public FitnessClient getClient(){
            return client;
        }



}

