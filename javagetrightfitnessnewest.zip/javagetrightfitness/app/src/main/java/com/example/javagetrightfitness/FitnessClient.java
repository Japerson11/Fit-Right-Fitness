package com.example.javagetrightfitness;

public class FitnessClient {
    private int id;
    private String name;
    private int heightFeet;
    private int heightInches;
    private double weight;
    private int age;
    private String gender;
    private String fitnessGoal;
    private String acctUsername;
    private String acctPassword;
    private int benchMax;
    private int squatMax;
    private int inclineMax;
    private int deadliftMax;
    private double totalHeightInCM;
    private double weightInKG;


    // constructor

    public FitnessClient()
    {
        this.id = 0;
        this.acctUsername = null;
        this.acctPassword = null;
        this.name = null;
        this.heightFeet = 0;
        this.heightInches = 0;
        this.weight = 0;
        this.age = 0;
        this.gender = null;
        this.fitnessGoal = null;
        this.benchMax = 0;
        this.squatMax = 0;
        this.inclineMax = 0;
        this.deadliftMax = 0;
    }

    public FitnessClient(int id, String acctUsername, String acctPassword, String name, int heightFeet, int heightInches
                    ,double weight, int age, String gender, String fitnessGoal, int benchMax, int squatMax, int inclineMax, int deadliftMax)
    {
        this.id = id;
        this.acctUsername = acctUsername;
        this.acctPassword = acctPassword;
        this.name = name;
        this.heightFeet = heightFeet;
        this.heightInches = heightInches;
        this.weight = weight;
        this.age = age;
        this.gender = gender;
        this.fitnessGoal = fitnessGoal;
        this.benchMax = benchMax;
        this.squatMax = squatMax;
        this.inclineMax = inclineMax;
        this.deadliftMax = deadliftMax;
    }


    // sign-in constructor

  /*  public FitnessClient(String acctUsername, String acctPassword)
    {
        this.acctUsername = acctUsername;
        this.acctPassword = acctPassword;
    } */

    public int getId() {
        return id;
    }

    public void setId(int id) { this.id = id; }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getHeightFeet() {
        return heightFeet;
    }

    public void setHeightFeet(int heightFeet) {
        this.heightFeet = heightFeet;
    }

    public int getHeightInches() {
        return heightInches;
    }

    public void setHeightInches(int heightInches) {
        this.heightInches = heightInches;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getFitnessGoal() {
        return fitnessGoal;
    }

    public void setFitnessGoal(String fitnessGoal) {
        this.fitnessGoal = fitnessGoal;
    }
    public String getAcctUsername() {
        return acctUsername;
    }

    public void setAcctUsername(String acctUsername) {
        this.acctUsername = acctUsername;
    }

    public String getAcctPassword() {
        return acctPassword;
    }

    public void setAcctPassword(String acctPassword) {
        this.acctPassword = acctPassword;
    }

    public int getBenchMax() {
        return benchMax;
    }

    public void setBenchMax(int benchMax) {
        this.benchMax = benchMax;
    }

    public int getSquatMax() {
        return squatMax;
    }

    public void setSquatMax(int squatMax) {
        this.squatMax = squatMax;
    }

    public int getInclineMax() {
        return inclineMax;
    }

    public void setInclineMax(int inclineMax) {
        this.inclineMax = inclineMax;
    }

    public int getDeadliftMax() {
        return deadliftMax;
    }

    public void setDeadliftMax(int deadliftMax) {
        this.deadliftMax = deadliftMax;
    }

    public double getTotalHeightInCM(){
        totalHeightInCM = (heightFeet * 12 + heightInches) * 2.54;

        return totalHeightInCM;
    }

    public double getWeightInKG(){
        weightInKG = (weight / 2.205);
        return weightInKG;
    }

    @Override
    public String toString() {
        return  "id," + id +                //1
                ",name," + name +           //3
                ",height," + heightFeet +   //5
                "," + heightInches +        //6
                ",weight," + weight +       //8
                ",age," + age +             //10
                ",gender," + gender +       //12
                ",fitnessGoal," + fitnessGoal + //14
                ",acctUsername," + acctUsername +   //16
                ",acctPassword," + acctPassword +   //18
                ",benchMax," + benchMax +           //20
                ",squatMax," + squatMax +           //22
                ",inclineMax," + inclineMax +       //24
                ",deadliftMax," + deadliftMax;      //26
    }

}
