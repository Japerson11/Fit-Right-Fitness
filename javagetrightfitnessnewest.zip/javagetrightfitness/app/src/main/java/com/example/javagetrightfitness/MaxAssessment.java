package com.example.javagetrightfitness;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MaxAssessment extends AppCompatActivity {

    Button doneButton;
    EditText etBenchMax, etInclineMax, etSquatMax, etDeadliftMax;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_max_assessment);

        doneButton = findViewById(R.id.btn_done);
        etBenchMax = findViewById(R.id.et_benchMax);
        etInclineMax = findViewById(R.id.et_inclineMax);
        etSquatMax = findViewById(R.id.et_squatMax);
        etDeadliftMax = findViewById(R.id.et_deadliftMax);



        doneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FitnessClient client = new FitnessClient();

                String clientString = getIntent().getExtras().getString("ourClient");

                String[] clientData = clientString.split(",");

                try{
                    client.setId(Integer.valueOf(clientData[1]));
                    client.setAcctUsername(clientData[16]);
                    client.setAcctPassword(clientData[18]);
                    client.setName(clientData[3]);
                    client.setHeightFeet(Integer.valueOf(clientData[5]));
                    client.setHeightInches(Integer.valueOf(clientData[6]));
                    client.setWeight(Double.valueOf(clientData[8]));
                    client.setAge(Integer.valueOf(clientData[10]));
                    client.setGender(clientData[12]);
                    client.setFitnessGoal(clientData[14]);
                    client.setBenchMax(Integer.valueOf(etBenchMax.getText().toString()));
                    client.setSquatMax(Integer.valueOf(etSquatMax.getText().toString()));
                    client.setInclineMax(Integer.valueOf(etInclineMax.getText().toString()));
                    client.setDeadliftMax(Integer.valueOf(etDeadliftMax.getText().toString()));

                } catch (Exception e) {
                    e.printStackTrace();
                }


                DataBaseHelper dataBaseHelper = new DataBaseHelper(MaxAssessment.this);

                boolean updated = dataBaseHelper.updateClientDB(client);

                Toast.makeText(MaxAssessment.this, "updated " + updated, Toast.LENGTH_SHORT).show();

                WorkoutCreator myWorkout = new WorkoutCreator(client);

                String armWorkout = "";
                String legWorkout = "";
                try {

                    armWorkout = myWorkout.generateArmWorkout();
                    legWorkout = myWorkout.generateLegWorkout();
                }
                catch (InterruptedException e)
                {
                    e.printStackTrace();
                }

                Intent intent = new Intent(MaxAssessment.this, WorkoutViewer.class);
                intent.putExtra("armWorkout", armWorkout);
                intent.putExtra("legWorkout", legWorkout);
                startActivity(intent);
            }
        });
    }

}