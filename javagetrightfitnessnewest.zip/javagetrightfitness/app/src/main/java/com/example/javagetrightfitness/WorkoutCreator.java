package com.example.javagetrightfitness;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class WorkoutCreator {
    private static final int CALORIE_DIFFERENCE = 500;
    private static final String BULK_REPS = " 1-6 reps ";
    private static final String BULK_SETS = " 3-6 sets ";
    private static final String SHRED_REPS = " 8-12 reps ";
    private static final String SHRED_SETS = " 1-3 sets ";
    private static final double BULK_MAX_MOD= .85;
    private static final double SHRED_MAX_MOD= .70;

    private Calendar calendar;
    private SimpleDateFormat dateFormat;
    private String dayOfWeekNum;
    private int dayCounter;
    private int streak;
    private int progressAdder;
    private int BMR;
    private String legWorkout;
    private String armWorkout;
    private int benchReppingWeight;
    private int inclineReppingWeight;
    private int squatReppingWeight;
    private int deadliftReppingWeight;
    private FitnessClient client;

    // constructor
    public WorkoutCreator(FitnessClient client){
        this.client = client;
    }
    public WorkoutCreator(){
        this.client = null;
    }

    // creates an arm workout
    public String generateArmWorkout() throws InterruptedException {
        setDayCounter();
        if (isBulking(client)) {
            benchReppingWeight = (int) (client.getBenchMax() * BULK_MAX_MOD + getProgressAdder());
            inclineReppingWeight = (int) (client.getInclineMax() * BULK_MAX_MOD + getProgressAdder());
            BMR = calculateBMR(client) + CALORIE_DIFFERENCE;
            armWorkout = "Your workout : " + "\n" + "Bench:" + BULK_SETS
                    + "for" + BULK_REPS + "at " + benchReppingWeight + "lbs"
                    + "\n" + "Incline:" + BULK_SETS + "for" + BULK_REPS
                    + "at " + inclineReppingWeight + "lbs" + "\n"
                    + "Recommended calories to consume today: " + BMR;
        }
        else {
            benchReppingWeight = (int) (client.getBenchMax() * SHRED_MAX_MOD + getProgressAdder());
            inclineReppingWeight = (int) (client.getInclineMax() * SHRED_MAX_MOD + getProgressAdder());
            BMR = calculateBMR(client) - CALORIE_DIFFERENCE;
            armWorkout = "Your workout : " + "\n" + "Bench:" + SHRED_SETS
                    + "for" + SHRED_REPS + "at " + benchReppingWeight + "lbs"
                    + "\n" + "Incline:" + SHRED_SETS + "for" + SHRED_REPS
                    + "at " + inclineReppingWeight + "lbs" + "\n"
                    + "Recommended calories to consume today: " + BMR;
        }

        return armWorkout;
    }

    // creates a leg workout
    public String generateLegWorkout() throws InterruptedException {
        setDayCounter();
        if (isBulking(client)) {
            squatReppingWeight = (int) (client.getSquatMax() * BULK_MAX_MOD) + getProgressAdder();
            deadliftReppingWeight = (int) (client.getDeadliftMax() * BULK_MAX_MOD + getProgressAdder());
            BMR = calculateBMR(client) + CALORIE_DIFFERENCE;
            legWorkout = "Your workout : " + "\n" + "Squat:" + BULK_SETS
                    + "for" + BULK_REPS + "at " + squatReppingWeight + "lbs"
                    + "\n" + "Dead Lift:" + BULK_SETS + "for" + BULK_REPS
                    + "at " + deadliftReppingWeight + "lbs" + "\n"
                    + "Recommended calories to consume today: " + BMR;
        }
        else {
            squatReppingWeight = (int) (client.getSquatMax() * SHRED_MAX_MOD + getProgressAdder());
            deadliftReppingWeight = (int) (client.getDeadliftMax() * SHRED_MAX_MOD + getProgressAdder());
            BMR = calculateBMR(client) - CALORIE_DIFFERENCE;
            legWorkout = "Your workout : " + "\n" + "Squat:" + SHRED_SETS
                    + "for" + SHRED_REPS + "at " + squatReppingWeight + "lbs"
                    + "\n" + "Dead Lift:" + SHRED_SETS + "for" + SHRED_REPS
                    + "at " + deadliftReppingWeight + "lbs" + "\n"
                    + "Recommended calories to consume today: " + BMR;
        }

        return legWorkout;
    }

    // Generates calorie requirement / basal metabolic rate (BMR) from Mifflin st. Jeor equation.
    public int calculateBMR(FitnessClient client) {
        if (client.getGender().equals("MALE")){
            BMR = (int) ( (10 * (client.getWeight() / 2.205))
                    + (6.25 * client.getTotalHeightInCM())
                    - (5 * client.getAge()) + 5);
        }
        else{
            BMR = (int) ( (10 * (client.getWeight() / 2.205))
                    + 6.25 * client.getTotalHeightInCM()
                    - 5 * client.getAge() - 161);
        }
        return BMR;
    }

    // returns whether or not the client is bulking
    public boolean isShredding(FitnessClient client) {
        if (client.getFitnessGoal().equals("Shred"))
            return true;
        else
            return false;
    }

    // returns whether or not the client is bulking
    public boolean isBulking(FitnessClient client) {
        if (client.getFitnessGoal().equals("Bulk"))
            return true;
        else
            return false;
    }

    public String getDayOfWeekNum(){
        dateFormat = new SimpleDateFormat("u");
        dayOfWeekNum = dateFormat.format(Calendar.getInstance().getTime());
        return dayOfWeekNum;
    }

    // returns day counter
    public int getDayCounter() {
        return dayCounter;
    }

    // counts to 28days then resets
    public void setDayCounter() throws InterruptedException {
            dayCounter++;
            if (dayCounter == 28) {
                dayCounter = 0;
                setStreak(streak++);
                setProgressAdder(getStreak());
            }


    }

    // returns an addition to the weight the user will be lifting
    // that increases every 28days.
    public int getProgressAdder() {
        return progressAdder;
    }

    // sets progressAdder
    public void setProgressAdder(int streak) {
       progressAdder = 5;
       if (getDayCounter() == 28){
           progressAdder = progressAdder * streak;
       }

    }

    // returns how many times the user used the app for 28 days
    public int getStreak() {
        return streak;
    }

    // sets streak
    public void setStreak(int streak) {
        this.streak = streak;
    }

    public String getClientName(){
        String name = client.getName();
        return name;
    }
}
