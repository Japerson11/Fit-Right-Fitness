package com.example.javagetrightfitness;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class WorkoutViewer extends AppCompatActivity {

    Button workButton;
    WorkoutCreator workoutC;
    TextView workoutText, welcome, logout;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout_viewer);

        workButton = findViewById(R.id.btn_workout);
        workoutC = new WorkoutCreator();
        workoutText = findViewById(R.id.workshower);
        welcome = findViewById(R.id.tv_welcome);
        welcome.setText("Welcome!");
        logout = findViewById(R.id.logout);


        workButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String armWorkout = getIntent().getExtras().getString("armWorkout");
                String legWorkout = getIntent().getExtras().getString("legWorkout");
                welcome.setText("Workout of the day:");

                if (workButton.getText().equals("Click when ready") || workButton.getText().equals("Click again for today's workout")) {
                    try {

                        if (workoutC.getDayOfWeekNum().equals("1") || workoutC.getDayOfWeekNum().equals("4"))
                            workoutText.setText(armWorkout);
                        else if (workoutC.getDayOfWeekNum().equals("2") || workoutC.getDayOfWeekNum().equals("5"))
                            workoutText.setText(legWorkout);
                        else
                            workoutText.setText("This is a rest day!");


                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    workButton.setText("click for tomorrow's workout");
                }else{

                if (workoutC.getDayOfWeekNum().equals("1") || workoutC.getDayOfWeekNum().equals("4") || workoutC.getDayOfWeekNum().equals("7")){
                    welcome.setText("Tomorrow's Workout:");
                    workoutText.setText(legWorkout);
                    workButton.setText("Click again for today's workout");


                }
                else if(workoutC.getDayOfWeekNum().equals("3") || workoutC.getDayOfWeekNum().equals("2") || workoutC.getDayOfWeekNum().equals("5")){
                    welcome.setText("Tomorrow's Workout:");
                    workoutText.setText(armWorkout);
                    workButton.setText("Click again for today's workout");

                }
                else if( workoutC.getDayOfWeekNum().equals("6")){
                    welcome.setText("Tomorrow's Workout:");
                    workoutText.setText("Hooray! Tomorrow is a rest day!");
                    workButton.setText("Click again for today's workout");

                }


                }
            }

        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WorkoutViewer.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
