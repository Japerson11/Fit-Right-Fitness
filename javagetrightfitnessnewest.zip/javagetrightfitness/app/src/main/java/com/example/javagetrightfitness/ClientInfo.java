package com.example.javagetrightfitness;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ToggleButton;

public class ClientInfo extends AppCompatActivity {

    Button infoSubmit;
    EditText etName, etHeightFeet, etHeightInch, etWeight, etAge;
    ToggleButton toggleGender, toggleGoal;
    private static final String TAG = "ClientInfo";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_info);

        infoSubmit = findViewById(R.id.btn_infosubmit);
        etName = findViewById(R.id.et_name);
        etHeightFeet = findViewById(R.id.et_heightfeet);
        etHeightInch = findViewById(R.id.et_heightinches);
        etWeight = findViewById(R.id.et_weight);
        etAge = findViewById(R.id.et_age);
        toggleGender = findViewById(R.id.toggle_gender);
        toggleGoal = findViewById(R.id.toggle_goal);



        infoSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FitnessClient client = new FitnessClient();

                String clientString = getIntent().getExtras().getString("ourClient");

                String[] clientData = clientString.split(",");


                try {
                        client.setId(Integer.valueOf(clientData[1]));
                        client.setAcctUsername(clientData[16]);
                        client.setAcctPassword(clientData[18]);
                        client.setName(etName.getText().toString());
                        client.setHeightFeet(Integer.valueOf(etHeightFeet.getText().toString()));
                        client.setHeightInches(Integer.valueOf(etHeightInch.getText().toString()));
                        client.setWeight(Double.valueOf(etWeight.getText().toString()));
                        client.setAge(Integer.valueOf(etAge.getText().toString()));
                        client.setGender(toggleGender.getText().toString());
                        client.setFitnessGoal(toggleGoal.getText().toString());

                        Toast.makeText(ClientInfo.this, "update complete ", Toast.LENGTH_SHORT).show();



                } catch (Exception e) {
                    e.printStackTrace();
                }

                //DataBaseHelper dataBaseHelper = new DataBaseHelper(ClientInfo.this);

                //boolean updated = dataBaseHelper.updateClientDB(client);


                //Toast.makeText(ClientInfo.this, "updated " + updated, Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(ClientInfo.this, MaxAssessment.class);
                intent.putExtra("ourClient", client.toString());
                startActivity(intent);
            }
        });

    }
}