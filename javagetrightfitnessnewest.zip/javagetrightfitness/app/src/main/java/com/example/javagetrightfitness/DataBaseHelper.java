package com.example.javagetrightfitness;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DataBaseHelper extends SQLiteOpenHelper {

    public static final String CLIENT_TABLE = "CLIENT_TABLE";
    public static final String COLUMN_CLIENT_ID = "CLIENT_ID";
    public static final String COLUMN_CLIENT_NAME = "CLIENT_NAME";
    public static final String COLUMN_HEIGHTFEET = "HEIGHTFEET";
    public static final String COLUMN_HEIGHTINCH = "HEIGHTINCH";
    public static final String COLUMN_WEIGHT = "CLIENT_WEIGHT";
    public static final String COLUMN_AGE = "CLIENT_AGE";
    public static final String COLUMN_GENDER = "CLIENT_GENDER";
    public static final String COLUMN_FITNESS_GOAL = "FITNESS_GOAL";
    public static final String COLUMN_USERNAME = "USERNAME";
    public static final String COLUMN_PASSWORD = "PASSWORD";
    public static final String COLUMN_BENCHMAX = "BENCH_MAX";
    public static final String COLUMN_SQUATMAX = "SQUAT_MAX";
    public static final String COLUMN_INCLINEMAX = "INCLINE_MAX";
    public static final String COLUMN_DEADLIFTMAX = "DEADLIFT_MAX";

    public DataBaseHelper(@Nullable Context context) {
        super(context, "client.db", null, 1);
    }

    //creates the database
    @Override
    public void onCreate(SQLiteDatabase db) {
        String tableCreator = "CREATE TABLE " + CLIENT_TABLE + " (" + COLUMN_CLIENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_CLIENT_NAME + " TEXT, " + COLUMN_HEIGHTFEET + " INT, " + COLUMN_HEIGHTINCH + " INT, "
                + COLUMN_WEIGHT + " FLOAT(1), " + COLUMN_AGE + " INT, " + COLUMN_GENDER + " TEXT, " + COLUMN_FITNESS_GOAL + " TEXT, " + COLUMN_USERNAME + " TEXT, " + COLUMN_PASSWORD + " TEXT, " + COLUMN_BENCHMAX + " INT, "
                + COLUMN_SQUATMAX + " INT, " + COLUMN_INCLINEMAX + " INT, " + COLUMN_DEADLIFTMAX + " INT)";

        db.execSQL(tableCreator);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean addClient(FitnessClient fitnessClient) {

            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues cv = new ContentValues();

            cv.put(COLUMN_USERNAME, fitnessClient.getAcctUsername());
            cv.put(COLUMN_PASSWORD, fitnessClient.getAcctPassword());
            cv.put(COLUMN_CLIENT_NAME, fitnessClient.getName());
            cv.put(COLUMN_HEIGHTFEET, fitnessClient.getHeightFeet());
            cv.put(COLUMN_HEIGHTINCH, fitnessClient.getHeightInches());
            cv.put(COLUMN_WEIGHT, fitnessClient.getWeight());
            cv.put(COLUMN_AGE, fitnessClient.getAge());
            cv.put(COLUMN_GENDER, fitnessClient.getGender());
            cv.put(COLUMN_FITNESS_GOAL, fitnessClient.getFitnessGoal());
            cv.put(COLUMN_BENCHMAX, fitnessClient.getBenchMax());
            cv.put(COLUMN_SQUATMAX, fitnessClient.getSquatMax());
            cv.put(COLUMN_INCLINEMAX, fitnessClient.getInclineMax());
            cv.put(COLUMN_DEADLIFTMAX, fitnessClient.getDeadliftMax());


            long insert = db.insert(CLIENT_TABLE, null, cv);

            if (insert == -1) {
                return false;
            } else {
                return true;
            }
        }


    // Returns all of the records in the client table
   /* public List<FitnessClient> getClients()
    {
        List<FitnessClient> clientList = new ArrayList<>();

        // get data from the database
        String queryString = "SELECT * FROM " + CLIENT_TABLE;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);

        if (cursor.moveToFirst()){

            do {
                int clientID = cursor.getInt(1);
                String clientName = cursor.getString(2);
                int clientHeightFeet = cursor.getInt(3);
                int clientHeightInch = cursor.getInt(4);
                Double clientWeight = cursor.getDouble(5);
                int clientAge = cursor.getInt(6);
                String clientGender = cursor.getString(7);
                String clientGoal = cursor.getString(8);
                String clientUsername = cursor.getString(9);
                String clientPassword = cursor.getString(10);
                int clientBenchMax = cursor.getInt(11);
                int clientSquatMax = cursor.getInt(12);
                int clientInclineMax = cursor.getInt(13);
                int clientDeadliftMax = cursor.getInt(14);

                FitnessClient newFitnessClient = new FitnessClient(clientID, clientUsername, clientPassword, clientName
                        , clientHeightFeet, clientHeightInch, clientWeight, clientAge, clientGender, clientGoal, clientBenchMax, clientSquatMax, clientInclineMax, clientDeadliftMax);

                clientList.add(newFitnessClient);

            } while (cursor.moveToNext());
        } else {
            //do nothing
        }

        cursor.close();
        db.close();
        return clientList;

    }*/

    // finds the client, deletes them, and returns true, otherwise it will return false
    public boolean deleteClient(FitnessClient client){
        SQLiteDatabase db = getWritableDatabase();
        String queryString = "DELETE FROM " + CLIENT_TABLE + " WHERE " + COLUMN_CLIENT_ID + " = " + client.getId();

        Cursor cursor = db.rawQuery(queryString, null);


        if (cursor.moveToFirst()){
            cursor.close();
            db.close();
            return true;
        }
        else{
            cursor.close();
            db.close();
            return false;
        }

    }

    // If the client exists in the database, the method returns true, otherwise it will return false
    public boolean clientExists(FitnessClient client){
        SQLiteDatabase db = getReadableDatabase();
        String queryString = "SELECT FROM " + CLIENT_TABLE + " WHERE " + COLUMN_USERNAME + " = " + client.getAcctUsername() + " AND "
                            + COLUMN_PASSWORD + " = " + client.getAcctPassword();

        Cursor cursor = db.rawQuery(queryString, null);


        if (cursor.moveToFirst()){
            cursor.close();
            db.close();
            return true;
        }
        else{
            cursor.close();
            db.close();
            return false;
        }

    }

    // updates the database
  /*  public boolean updateClientDB(FitnessClient fitnessClient){
        SQLiteDatabase db = getWritableDatabase();
        String queryString = "UPDATE FROM " + CLIENT_TABLE + " SET " + COLUMN_HEIGHTFEET + " = " + fitnessClient.getHeightFeet() + ", "
                            + COLUMN_HEIGHTINCH + " = " + fitnessClient.getHeightInches() + ", " + COLUMN_WEIGHT + " = " + fitnessClient.getWeight()
                            + ", " + COLUMN_AGE + " = " + fitnessClient.getAge() + ", " + COLUMN_GENDER + " = " + fitnessClient.getGender()
                            + ", " + COLUMN_FITNESS_GOAL + " = " + fitnessClient.getFitnessGoal() + ", " + COLUMN_BENCHMAX + " = " + fitnessClient.getBenchMax()
                            + ", " + COLUMN_SQUATMAX + " = " + fitnessClient.getSquatMax() + ", " + COLUMN_INCLINEMAX + " = " + fitnessClient.getInclineMax()
                            + ", " + COLUMN_DEADLIFTMAX + " = " + fitnessClient.getDeadliftMax() + " WHERE " + COLUMN_CLIENT_ID + " = " + fitnessClient.getId();

        Cursor cursor = db.rawQuery(queryString, null);

        if (cursor.moveToFirst()){
            cursor.close();
            db.close();
            return true;
        }
        else{
            cursor.close();
            db.close();
            return false;
        }
    }*/

    public boolean updateClientDB(FitnessClient fitnessClient) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        //cv.put(COLUMN_CLIENT_ID, fitnessClient.getId());
        cv.put(COLUMN_USERNAME, fitnessClient.getAcctUsername());
        cv.put(COLUMN_PASSWORD, fitnessClient.getAcctPassword());
        cv.put(COLUMN_CLIENT_NAME, fitnessClient.getName());
        cv.put(COLUMN_HEIGHTFEET, fitnessClient.getHeightFeet());
        cv.put(COLUMN_HEIGHTINCH, fitnessClient.getHeightInches());
        cv.put(COLUMN_WEIGHT, fitnessClient.getWeight());
        cv.put(COLUMN_AGE, fitnessClient.getAge());
        cv.put(COLUMN_GENDER, fitnessClient.getGender());
        cv.put(COLUMN_FITNESS_GOAL, fitnessClient.getFitnessGoal());
        cv.put(COLUMN_BENCHMAX, fitnessClient.getBenchMax());
        cv.put(COLUMN_SQUATMAX, fitnessClient.getSquatMax());
        cv.put(COLUMN_INCLINEMAX, fitnessClient.getInclineMax());
        cv.put(COLUMN_DEADLIFTMAX, fitnessClient.getDeadliftMax());


        long insert = db.insert(CLIENT_TABLE, null, cv);

        if (insert == -1) {
            return false;
        } else {
            return true;
        }
    }

}